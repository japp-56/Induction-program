# Induction Program Notes

## Day 1
- Orientation speech by principal
- Campus tour
- Ice-breaking session

## Day 2
- Introduction to academics
- Faculty meet & greet
- Career goals workshop

## Day 3
- Communication skills workshop
- Team building activities

... (Add more days here)
